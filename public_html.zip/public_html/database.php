[
{
"sub" : "AI",
"title" : "Turning Test, if it quacks like a duck...",
"firstp" : "I'm known for practicality.  So the AI section can run in a million diffrent directions.  The point is to learn how to pass my conception of the Turing test. Hopefully along the way I find the most effective mix of methods or at least have a theoretical understanding of these things.",
"numpics":1,
"pics0":"datasmall.jpg",
"pics1":"datasmall.jpg"

},

{
"sub" : "webdev",
"title":"My instrest is purely how I can make this site awesome",
"firstp":"I like web development, pour myself a glass of wine late at night and just blow off steam fixing up a website.  I guess no intrest of mine is linear but this will be the most organized because it's all about functionality. My greatest question is can I make what I want with what I know?",
"numpics":2,
"pics0": "trees.jpg",
"pics1":"datasmall.jpg"
}
]

